#!/bin/bash
# Double-click starter for macOS. It runs the same single command as START_WINDOWS.cmd.
# The first time, macOS may ask for confirmation: right-click the file and choose Open.
cd "$(dirname "$0")" || exit 2

if [ ! -f run_reviewer.py ]; then
  echo "Extract the complete ZIP before opening this starter."
  echo "Keep START_MAC.command beside run_reviewer.py."
  STATUS=2
else
  PYTHON=""
  for candidate in python3.12 \
      /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
      /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 python3; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c \
        'import sys, struct; sys.exit(0 if sys.version_info[:2] == (3, 12) and struct.calcsize("P") == 8 else 1)' \
        >/dev/null 2>&1; then
      PYTHON="$candidate"
      break
    fi
  done
  if [ -z "$PYTHON" ]; then
    echo "These checks require 64-bit Python 3.12, which was not found on this computer."
    echo
    echo "Install it once from https://www.python.org/downloads/release/python-31210/"
    echo "Choose \"macOS 64-bit universal2 installer\", then double-click START_MAC.command again."
    STATUS=2
  else
    "$PYTHON" -I -B -u run_reviewer.py
    STATUS=$?
  fi
fi

echo
if [ "$STATUS" != "0" ]; then
  echo "The checks need attention. Read the report or message above."
fi
read -n 1 -s -r -p "Press any key to close this window."
echo
exit "$STATUS"
