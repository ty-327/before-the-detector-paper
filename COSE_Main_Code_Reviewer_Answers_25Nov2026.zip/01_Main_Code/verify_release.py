#!/usr/bin/env python3
"""Read-only integrity and inventory check for the COSE main-code package."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re

OS_METADATA = {'.ds_store', 'desktop.ini', 'thumbs.db'}
# Folders that the run itself, Git, an editor or an operating system may add at the
# top of the package. They are never read by the analysis and are skipped, not failed.
TOOL_FOLDERS = {'.reviewer_env', '.git', '.pytest_cache', '.idea', '.vscode', '__MACOSX'}
# Sidecar files an office program or macOS creates beside a file that is open or copied:
# "~$name" (Office lock file) and "._name" (macOS resource fork). Python cannot import them.
SIDECAR_PREFIXES = ('~$', '._')


def is_sidecar(name: str) -> bool:
    return name.casefold() in OS_METADATA or name.startswith(SIDECAR_PREFIXES)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def manifest_entries(root: Path) -> list[dict]:
    manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    entries = manifest.get('files') if isinstance(manifest, dict) else None
    if not isinstance(entries, list) or not entries:
        raise ValueError('The manifest must contain a nonempty files list')
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError('Each manifest entry must be an object')
        name = entry.get('path')
        if not isinstance(name, str):
            raise ValueError('Every manifest entry needs a path string')
        parts = name.split('/')
        if ('\\' in name or '\x00' in name or ':' in name
                or any(part in ('', '.', '..') for part in parts)
                or name == 'PACKAGE_MANIFEST.json'
                or parts[0] in TOOL_FOLDERS
                or '__pycache__' in parts or is_sidecar(parts[-1])):
            raise ValueError('Unsafe or excluded manifest path: ' + name)
        if name.casefold() in seen:
            raise ValueError('Duplicate manifest path: ' + name)
        seen.add(name.casefold())
        if type(entry.get('bytes')) is not int or entry['bytes'] < 0:
            raise ValueError('Invalid byte length for ' + name)
        value = entry.get('sha256')
        if not isinstance(value, str) or re.fullmatch(r'[0-9a-f]{64}', value) is None:
            raise ValueError('Invalid SHA-256 for ' + name)
    return entries


def package_files(root: Path, failed: list[str], skipped: list[str]) -> set[str]:
    files = set()
    for folder, directories, names in os.walk(root, followlinks=False):
        current = Path(folder)
        for name in list(directories):
            path = current / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                failed.append(relative + ': symbolic links are not release files')
                directories.remove(name)
            elif name == '__pycache__' or (current == root and name in TOOL_FOLDERS):
                if name in ('.idea', '.vscode', '__MACOSX'):
                    skipped.append(relative + '/')
                directories.remove(name)
        for name in names:
            path = current / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                failed.append(relative + ': symbolic links are not release files')
            elif relative in ('PACKAGE_MANIFEST.json', '.git'):
                continue
            elif is_sidecar(name):
                skipped.append(relative)
            else:
                files.add(relative)
    return files


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--raw', type=Path, help='Optional exact raw Kaggle ZIP to verify')
    args = parser.parse_args()
    root = args.root.resolve()
    failed = []
    try:
        entries = manifest_entries(root)
    except (OSError, ValueError) as exc:
        print('FAIL: manifest:', exc)
        return 1
    skipped: list[str] = []
    actual = package_files(root, failed, skipped)
    declared = {entry['path'] for entry in entries}
    failed.extend(name + ': unlisted file' for name in sorted(actual - declared))
    for entry in entries:
        name = entry['path']
        path = root / name
        if name not in actual or not path.is_file():
            failed.append(name + ': missing or not a regular release file')
            continue
        try:
            if path.stat().st_size != entry['bytes'] or digest(path) != entry['sha256']:
                failed.append(name + ': size/hash mismatch')
        except OSError as exc:
            failed.append(name + ': ' + str(exc))
    if args.raw:
        expected = 'e00557bd8dc6d5e1a09f8da36213039ac23950f9613e245db49c6ef564ce6df7'
        if not args.raw.is_file():
            failed.append('Raw archive: not found')
        elif args.raw.stat().st_size != 901195556 or digest(args.raw) != expected:
            failed.append('Raw archive: not the pinned snapshot')
        else:
            print('PASS: raw archive size and SHA-256')
    else:
        print('Raw archive not supplied to this preflight; verify it before running reproduce.py.')
    print(f'Checked {len(entries)} packaged files; mismatches: {len(failed)}')
    if skipped:
        print(f'Ignored {len(skipped)} editor or system items that are not part of the package: '
              + ', '.join(sorted(skipped)[:8]) + (' ...' if len(skipped) > 8 else ''))
    for message in failed:
        print('FAIL:', message)
    print('No analytical code, settings, outputs or raw data were modified.')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
