# Before the Detector: main analysis code

Manuscript COSE-D-26-04938, *Computers & Security*, Revision 1.

## Download and run in four steps

1. **Install 64-bit Python 3.12 once**, if it is not already installed. The
   [Python 3.12.10 download page](https://www.python.org/downloads/release/python-31210/)
   provides Windows and Mac installers. On Windows choose **Windows installer
   (64-bit)** and select **Add python.exe to PATH**.
2. **Download and extract the complete ZIP.** On Windows, right-click it and
   choose **Extract All**. Use a short, writable folder such as `C:\cose`.
3. **Open `01_Main_Code` and double-click `START_WINDOWS.cmd`.** On a Mac,
   right-click `START_MAC.command` and choose **Open**. Keep the window open;
   the first run needs internet access to install the required libraries.
4. **Read the result.** A successful run shows **MAIN REVIEWER CHECKS PASSED**
   and opens **REVIEWER_ANSWERS.html** on Windows or Mac. The results folder is
   printed in the window. If the run needs attention, read
   **REVIEWER_CHECK_REPORT.txt** in that folder for the reason and log locations.

Both starters call `run_reviewer.py`. To run it from a terminal opened in this folder:

| System | Command |
| --- | --- |
| Windows | `py -3.12 -I -B run_reviewer.py` |
| macOS or Linux | `python3.12 -I -B run_reviewer.py` |

On Linux, open the report at the printed path. The package requires 64-bit Python
3.12 and creates its own private environment with the exact versions in
`requirements.txt`; nothing is installed into your system Python.

## What you will see

The window shows progress and, after a few minutes, ends with

```text
MAIN REVIEWER CHECKS PASSED
```

followed by one summary line per reviewer comment. The full report,
**REVIEWER_ANSWERS.html**, opens in your browser on Windows or Mac. It is organized by reviewer
comment:

| Reviewer comment | Section of the report |
| --- | --- |
| Reviewer 1, comment 1 | Ramp, delayed, distributed and heterogeneous responses: coefficients and detection floors |
| Reviewer 1, comment 2 | Two-way fixed-effects estimate, standard error, interval and sample |
| Reviewer 1, comment 3 | Detection floor: recovery rate, Wilson interval, adjacent doses, resampling ranges, calibration |
| Reviewer 1, comment 4 | Principal selection rules, thresholds, seeds, dose grid and repetition counts, with their sources |
| Reviewer 2, comment 2 | Code, item classifications, exclusions, randomization dates, file hashes, collectibles index |
| Reviewer 2, comment 4 | How the synthetic volume is distributed, the grid, the repetitions, the result without containers |
| Reviewer 2, comment 5 | Completed data-quality checks: missing observations, duplicates, currency, time zone, sub-daily records |

Under every table a line states how the numbers were obtained: recomputed in this
run, regenerated from saved model output and compared with the manuscript, or
taken from the saved record of the raw-data run.

If anything fails, the window stays open, the result reads
`MAIN REVIEWER CHECKS NEED ATTENTION`, and the reason is shown.

## Where the results are

Each run writes a new folder under `Downloads/COSE_Reviewer_Results` (or the home
folder when there is no Downloads folder). Nothing is written into this package
except the private environment, `.reviewer_env`.

| File or folder | Contents |
| --- | --- |
| `REVIEWER_ANSWERS.html` | The answers, by reviewer comment |
| `REVIEWER_ANSWERS.json` | The same tables in machine-readable form |
| `REVIEWER_CHECK_REPORT.txt` | Pass or fail for each group of checks, and the scope |
| `1_main.log` | Complete output of the run |
| `2_answers.log` | Output from building the reviewer answers report |
| `main_report/` | Agreement with the manuscript and the control cases |
| `main_replay/results/` | The regenerated result tables |

To choose the folder yourself: `python3.12 -I -B run_reviewer.py --report-dir PATH`
(the folder must not exist yet). Add `--no-open` to stop the report from opening.
On Windows, type `py -3.12` wherever this page shows `python3.12`.

## What the run establishes, and what it does not

The run regenerates 352 H2 result summaries and 6,608 recovery-curve rows from the
saved model output, repeats the arithmetic with separately written code, compares
ten reference tables cell by cell, and compares the displacement (H2),
detection-floor and key-premium (H3) values with the bundled manuscript. Control
cases then confirm that altered coefficients, floors, evidence files, random
arrays and tables are rejected.

The run does **not** refit the models. Fitting needs the public raw archive
(about 900 MB), which is not bundled; see the last section. The run also does not
recompute the accumulation result (H1), the spike-and-reversal analysis, or
Figures 2 and 3. The dated analysis plans and the separate data and figure
material are in their own packages.

Tested configuration for this update: Python 3.12.14 on Linux. Native Windows
and macOS execution has not been tested here. The starters call the same Python
entry point. The test record is in
`provenance/PACKAGE_HISTORY.json`.

## Folder guide

| Location | Purpose |
| --- | --- |
| `START_WINDOWS.cmd`, `START_MAC.command`, `run_reviewer.py` | The single starting point |
| `reviewer_answers.py` | Builds the answers report from a finished run |
| `run_revision1.py`, `reviewer_test.py`, `verify_release.py` | The checks that the starting point runs |
| `scripts/` | The analysis code: data preparation, estimators, simulation, summaries |
| `review_assets.zip` | Saved model output and reference tables used by the run |
| `reviewer_data/` | Item classifications and the construction of the collectibles index |
| `revision/`, `FINAL_SETTINGS.json` | Recorded settings, excluded containers and randomization dates |
| `revision1_reference/` | The manuscript and response workbook that results are compared with |
| `reviewer_tools/`, `revision1_validation/`, `launcher_tests/` | Comparison code and control cases |
| `inputs/`, `revision_extensions/`, `expected_v48/` | Inputs and reference values for the optional raw-data route |
| `revision1_comparator/` | Separate comparison of earlier results; needs the separate data package |
| `provenance/` | Package history, and the analysis code exactly as it was executed |

`RESULT_TO_SCRIPT_MAP.csv` lists, for every reported result, the script that
produces it and the file it is written to.

### Readable code and the code as executed

The analysis scripts were reformatted for reading: one statement per line, no
change of content. The files exactly as executed are kept in
`provenance/as_executed_sources.zip`. Every run confirms that each readable file
has the same syntax tree as its original; a difference stops the report.
Fingerprints of scripts recorded inside older record files refer to the
as-executed files.

## Housekeeping

- `PACKAGE_MANIFEST.json` records the size and SHA-256 fingerprint of every file.
  The run checks them before and after. A quick check on its own:
  `python3.12 -I -B verify_release.py`.
- Do not edit or add files in this folder: a changed or unlisted file stops the
  run. Folders and lock files that editors and operating systems create on their
  own (`.idea`, `.vscode`, `.DS_Store`, `~$...`) are ignored and reported.
- Keep `.gitattributes` with the code. It stops Git from changing line endings,
  which would change the fingerprints.
- When you have finished, delete `.reviewer_env` (roughly 0.5 GB) and the results
  folders (roughly 120 MB per run).

## Optional: full reconstruction from the raw data

The raw-data route refits every model from the public Kaggle archive identified
in `inputs/public_data_manifest.json`. Its launcher runs on Windows only and
processes the full archive, so expect a long run.

```text
python start_reproduction.py --help
python start_reproduction.py --dry-run --archive PATH_TO_RAW_ZIP --workspace NEW_FOLDER
python start_reproduction.py --archive PATH_TO_RAW_ZIP --workspace NEW_FOLDER
```

The first command explains the options. The second lists the twelve steps without
running anything, on any system. The third runs them.

The comparison of earlier results needs the separate data package:

```text
python compare_manuscript.py --data-dir "/path/to/03_Ty_Reproducibility_Data"
```

Its scope and return status are described in `revision1_comparator/README.txt`.
