@echo off
setlocal
title COSE Main Reviewer Checks
pushd "%~dp0"
if errorlevel 1 goto folder_error
if not exist "%~dp0run_reviewer.py" goto missing_files
py -3.12 -c "import sys,struct; sys.exit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys,struct; sys.exit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
echo These checks require 64-bit Python 3.12, which was not found on this computer.
echo.
echo Install it once from https://www.python.org/downloads/release/python-31210/
echo Choose "Windows installer (64-bit)" and tick "Add python.exe to PATH".
echo Then double-click START_WINDOWS.cmd again.
set "COSE_MAIN_EXIT=2"
goto done
:use_py
py -3.12 -I -B -u "%~dp0run_reviewer.py"
set "COSE_MAIN_EXIT=%errorlevel%"
goto done
:use_python
python -I -B -u "%~dp0run_reviewer.py"
set "COSE_MAIN_EXIT=%errorlevel%"
goto done
:missing_files
echo Extract the complete ZIP before opening this launcher.
echo Keep START_WINDOWS.cmd beside run_reviewer.py.
set "COSE_MAIN_EXIT=2"
goto done
:folder_error
echo Windows could not open this folder. Extract the ZIP to a writable folder.
pause
exit /b 2
:done
echo.
if not "%COSE_MAIN_EXIT%"=="0" echo The checks need attention. Read the report or message above.
echo Press any key to close this window.
pause >nul
popd
exit /b %COSE_MAIN_EXIT%
