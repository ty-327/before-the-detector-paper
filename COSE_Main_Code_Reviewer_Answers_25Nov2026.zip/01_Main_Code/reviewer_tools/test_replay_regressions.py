#!/usr/bin/env python3
"""Check replay binding and NPZ portability on disposable copies of a passed run."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import csv
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import zipfile

import numpy as np


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@contextmanager
def preserve(*paths):
    originals = {path: path.read_bytes() for path in paths}
    try:
        yield
    finally:
        for path, contents in originals.items():
            path.write_bytes(contents)


def change_threshold(path, result_id):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    selected = [row for row in rows if row["result_id"] == result_id]
    if len(selected) != 1:
        raise ValueError("Threshold mutation must select exactly one result")
    selected[0]["threshold"] = str(float(selected[0]["threshold"]) + 0.01)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--work-parent", type=Path)
    args = parser.parse_args()
    package, replay, report = args.package.resolve(), args.replay.resolve(), args.report.resolve()
    parent = (args.work_parent or replay.parent).resolve()
    result = {"status": "RUNNING", "all_required_tests_passed": False, "cases": [],
              "scope": "Binding and portability controls on copies; no scientific refit",
              "fresh_raw_extraction": False, "fresh_primary_model_fit": False}
    if any(parent == path or parent.is_relative_to(path) for path in (package, replay)):
        parser.error("Temporary working files must be outside the package and source replay")
    if report.is_relative_to(package) or report.is_relative_to(replay):
        parser.error("The report must be outside the package and source replay")
    try:
        receipt = json.loads((replay / "REVIEW_TEST_RESULT.json").read_text(encoding="utf-8"))
        if receipt.get("status") != "PASS" or receipt.get("mode") != "saved_evidence_replay":
            raise ValueError("A passed saved-evidence replay is required")
        api = runpy.run_path(str(package / "run_revision1.py"))
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
        with tempfile.TemporaryDirectory(prefix="replay_regressions_", dir=parent) as temporary:
            work = Path(temporary) / "replay"
            shutil.copytree(replay, work, ignore=shutil.ignore_patterns("logs", "__pycache__"))

            def bind():
                checked = api["bind_replay"](work, sys.executable)
                if checked.get("status") != "PASS":
                    raise AssertionError("Binding did not return PASS")
                return {"binding": "PASS", "arrays_verified":
                        checked["current_evidence_verification"]["arrays_verified"]}

            def portability(label):
                details = bind()
                destination = Path(temporary) / (label + ".json")
                command = [sys.executable, str(package / "reviewer_tools/test_portability_integrity.py"),
                           "--replay", str(work), "--report", str(destination),
                           "--work-parent", str(Path(temporary))]
                completed = subprocess.run(command, env=env, capture_output=True, text=True)
                checked = json.loads(destination.read_text(encoding="utf-8"))
                if completed.returncode or not checked.get("all_required_tests_passed"):
                    raise AssertionError("Portability suite failed: " + str(checked.get("error", completed.stderr)))
                details.update(portability_exit_code=completed.returncode, portability_cases=checked["cases"])
                return details

            def case(name, action, expected_error=None):
                entry = {"case": name, "expected": "REJECT" if expected_error else "PASS"}
                try:
                    entry.update(action())
                    entry["test_passed"] = expected_error is None
                except Exception as exc:
                    entry.update(observed_error=str(exc), error_type=type(exc).__name__,
                                 test_passed=expected_error is not None and expected_error in str(exc))
                if expected_error:
                    entry["required_error"] = expected_error
                result["cases"].append(entry)

            case("unchanged_replay", bind)
            recipe = json.loads((work / "reviewer_tools/REPLAY_INDEX_RECIPE.json").read_text())
            targets = [work / entry["path"] for entry in recipe["files"]]
            with preserve(*targets):
                for target in targets:
                    with zipfile.ZipFile(target) as archive:
                        members = [(item.filename, archive.read(item)) for item in archive.infolist()]
                    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
                        archive.comment = b"COSE regression alternative container"
                        for name, contents in members:
                            archive.writestr(name, contents)
                case("all_seven_valid_alternative_containers", lambda: portability("all_alternative"))

            with preserve(targets[0]):
                with np.load(targets[0], allow_pickle=False) as archive:
                    arrays = {name: archive[name] for name in archive.files}
                np.savez(targets[0], **arrays)
                saved = digest(targets[0])
                np.savez(targets[0], **arrays)
                if digest(targets[0]) != saved:
                    raise AssertionError("ZIP_STORED fixture is not already in the control's serialization")
                case("target_already_stored_by_numpy", lambda: portability("already_stored"))

            manifest_path = work / "audit/REUSED_FILE_MANIFEST.json"
            coefficient_path = work / "evidence/dell/eventual/all_TWFE_neutral_step.npz"
            with preserve(manifest_path, coefficient_path):
                with np.load(coefficient_path, allow_pickle=False) as archive:
                    arrays = {name: archive[name] for name in archive.files}
                arrays["coefficients"][0, 0] += 0.01
                np.savez_compressed(coefficient_path, **arrays)
                manifest = json.loads(manifest_path.read_text())
                relative = coefficient_path.relative_to(work).as_posix()
                matched = [entry for entry in manifest if entry["evidence"].replace("\\", "/") == relative]
                if len(matched) != 1:
                    raise AssertionError("Evidence mutation must select exactly one manifest entry")
                matched[0]["sha256"] = digest(coefficient_path)
                manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
                case("changed_coefficient_and_refreshed_manifest", bind,
                     "Replay evidence manifest differs from the packaged source")

            result_table = work / "results/FINAL_RESULTS.csv"
            reference_table = work / "reference_results/FINAL_RESULTS.csv"
            with result_table.open(newline="", encoding="utf-8-sig") as stream:
                result_id = next(csv.DictReader(stream))["result_id"]
            with preserve(result_table):
                change_threshold(result_table, result_id)
                case("changed_result_with_previous_pass_receipt", bind,
                     "Current replay result tables failed reference comparison")
            with preserve(result_table, reference_table):
                change_threshold(result_table, result_id)
                change_threshold(reference_table, result_id)
                case("changed_local_reference_and_result", bind,
                     "Replay reference table differs from the packaged source:")

        result["all_required_tests_passed"] = (len(result["cases"]) == 6
                                               and all(case["test_passed"] for case in result["cases"]))
        result["status"] = "PASS" if result["all_required_tests_passed"] else "FAIL"
        result["source_replay_receipt_sha256"] = digest(replay / "REVIEW_TEST_RESULT.json")
    except Exception as exc:
        result.update(status="FAIL", error=str(exc))
    result["completed_utc"] = datetime.now(timezone.utc).isoformat()
    report.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(result, indent=2) + "\n"
    report.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if result["all_required_tests_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
