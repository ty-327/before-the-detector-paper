#!/usr/bin/env python3
"""Build the reviewer-facing answers report from one completed reviewer run.

The report is organized by reviewer comment. Every result is read from the files
written by the run that has just finished, or from a named file in this package.
Displayed results come from those records. Values that the run has already compared with
the manuscript are read back from that comparison and cross-checked here, so the
report cannot silently disagree with the checks. If a cross-check fails, no report
is written and the run is reported as failed.

Usage (run_reviewer.py does this automatically after a successful run):
    python reviewer_answers.py --results RESULTS_FOLDER
"""

from __future__ import annotations

import argparse
import ast
import csv
from datetime import date, datetime, timedelta, timezone
import html
import json
import math
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent

# How each number was obtained. The wording appears under every table.
NOW = "Recomputed in this run from the files in the package."
REPLAY = (
    "Regenerated in this run from the saved model output, then compared with the "
    "manuscript by the run's own checks."
)
SAVED_FIT = (
    "Saved model fit from the raw-data run (the model is not refitted here); "
    "compared with the manuscript in this run."
)
SAVED = (
    "Saved record of the raw-data run. Not recomputed here: the raw data are not in the package."
)

PROFILE_LABELS = {
    "step": "Abrupt step",
    "ramp7": "7-day ramp",
    "ramp21": "21-day ramp",
    "delay7": "7-day delay",
    "delay14": "14-day delay",
    "delay28": "28-day delay",
    "distributed": "Distributed onset",
    "heterogeneous": "Heterogeneous adjustment",
}
STATUS_WORDS = {
    "MATCH": "Match",
    "MATCH_TO_RETAINED_CALCULATION": "Match with the saved calculation",
}

# The manuscript reports range (a) below. Ranges (b) and (c) come from the same regenerated table
# and are wider because they also resample the calibration dates. Set this to False to show
# only the range reported in the manuscript.
SHOW_CALIBRATION_INCLUSIVE_RANGES = True
GROUP_LABELS = {"all": "All candidates", "exclude_cases": "Excluding key-dependent containers"}

# The selection rule, restated from scripts/audit_raw.py so that it can be re-applied here.
# section_selection() fails if these values stop reproducing the arms recorded in the item file.
CANDIDATE_MAX_PRICE = 10.0  # median pre-intervention price, USD, strictly below
CONTROL_MIN_PRICE = 50.0  # median pre-intervention price, USD, strictly above
MIN_PRE_DAYS = 180  # observed pre-intervention days, candidates and controls
LIQUIDITY_QUANTILE = 0.75  # candidates must exceed this quantile of median daily units


# ----------------------------------------------------------------------------- helpers
def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def one(rows: list[dict], **where) -> dict:
    """Return the single row that matches every condition; anything else is an error."""
    found = [row for row in rows if all(row.get(key) == value for key, value in where.items())]
    if len(found) != 1:
        raise ValueError(f"Expected exactly one row for {where}; found {len(found)}")
    return found[0]


def close(a: float, b: float, tolerance: float = 1e-9) -> bool:
    return math.isclose(a, b, rel_tol=tolerance, abs_tol=tolerance)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError("Answers cross-check failed: " + message)


def pct(fraction: float) -> str:
    """Format a dose given as a fraction of candidate volume, for example 0.35 -> 35%."""
    value = 100 * float(fraction)
    return f"{value:.0f}%" if close(value, round(value), 1e-9) else f"{value:g}%"


def num(value, digits: int = 4) -> str:
    return f"{float(value):.{digits}f}"


def count(value) -> str:
    return f"{int(round(float(value))):,}"


def wilson(successes: float, trials: float, z: float = 1.959963984540054) -> tuple[float, float]:
    p = successes / trials
    denominator = 1 + z * z / trials
    centre = (p + z * z / (2 * trials)) / denominator
    half = z * math.sqrt(p * (1 - p) / trials + z * z / (4 * trials * trials)) / denominator
    return centre - half, centre + half


def quantile_type7(values: list[float], q: float) -> float:
    """Linear-interpolation quantile, the default of the numerical library used by the analysis."""
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


# ----------------------------------------------------------------------------- sections
def section_status(results: Path) -> dict:
    status = read_json(results / "main_report/REVISION1_STATUS.json")
    replay = read_json(results / "main_replay/REVIEW_TEST_RESULT.json")
    negative = read_json(results / "main_report/NEGATIVE_TESTS.json")
    portability = read_json(results / "main_report/PORTABILITY_INTEGRITY_TESTS.json")
    regression = read_json(results / "main_report/REPLAY_REGRESSION_TESTS.json")
    require(
        replay.get("status") == "PASS"
        and bool(replay.get("completed_utc"))
        and replay.get("mode") == "saved_evidence_replay"
        and replay.get("source_package_verified_before_and_after") is True,
        "the saved-evidence replay did not pass",
    )
    require(
        bool(replay.get("stages"))
        and all(stage.get("status") == "PASS" for stage in replay["stages"]),
        "not all replay stages passed",
    )
    comparison = replay.get("reference_comparison", {})
    require(
        comparison.get("status") == "PASS"
        and comparison.get("required_table_count") == 10
        and comparison.get("passed_table_count") == 10
        and comparison.get("failed_table_count") == 0,
        "the ten reference tables did not all match",
    )
    require(
        status.get("reviewer_requested_h2_agreement") == "MATCH"
        and bool(status.get("completed_utc"))
        and status.get("historical_h3") == "MATCH_TO_RETAINED_CALCULATION"
        and status.get("negative_tests") == "EXPECTED_FAILURES_OBSERVED"
        and status.get("portability_integrity_controls") == "PASS"
        and status.get("replay_regression_controls") == "PASS"
        and not status.get("execution_error"),
        "the completed reviewer run did not pass",
    )
    require(
        portability.get("status") == "PASS" and regression.get("status") == "PASS",
        "the portability or replay regression suite did not pass",
    )
    for label, block, expected_cases in (
        ("changed-result controls", negative, 4),
        ("portability controls", portability, 8),
        ("replay regression controls", regression, 6),
    ):
        cases = block.get("cases", [])
        require(
            block.get("all_required_tests_passed") is True
            and len(cases) == expected_cases
            and all(case.get("test_passed") is True for case in cases),
            f"{label} did not all pass",
        )
    controls = sum(len(block["cases"]) for block in (negative, portability, regression))
    rows = [
        ["Result summaries regenerated", count(replay["summary_rows"])],
        ["Recovery-curve rows regenerated", count(replay["recovery_curve_rows"])],
        ["Arithmetic checks passed", count(replay["arithmetic_checks_passed"])],
        [
            "Reference tables matched",
            f"{replay['reference_comparison']['passed_table_count']} of "
            f"{replay['reference_comparison']['required_table_count']}",
        ],
        ["Estimator and simulation unit tests passed", count(replay["computational_tests_passed"])],
        ["Launcher tests passed", count(replay["launcher_tests_passed"])],
        [
            "Control cases (altered results must be rejected)",
            f"{controls} of {controls} behaved as required",
        ],
        [
            "Displacement (H2) and detection-floor values against the manuscript",
            STATUS_WORDS.get(
                status["reviewer_requested_h2_agreement"], status["reviewer_requested_h2_agreement"]
            ),
        ],
        [
            "Key-premium (H3) values against the manuscript",
            STATUS_WORDS.get(status["historical_h3"], status["historical_h3"]),
        ],
    ]
    return {"rows": rows, "status": status, "replay": replay}


def section_h2(results: Path, derived: dict) -> dict:
    baselines = read_csv(results / "main_replay/results/BASELINES_AND_DENOMINATORS.csv")
    table, values = [], {}
    for group in ("all", "exclude_cases"):
        row = one(baselines, cohort="full", group=group, model="TWFE")
        values[group] = row
        table.append(
            [
                GROUP_LABELS[group],
                num(row["coefficient"]),
                num(row["se_two_way"]),
                f"{num(row['ci_low_two_way'])} to {num(row['ci_high_two_way'])}",
                f"{float(row['percent_log_transform']):.2f}%",
                f"{count(row['candidate_items'])} / {count(row['control_items'])}",
                count(row["n"]),
                count(row["dates"]),
            ]
        )
    main = values["all"]
    require(close(float(main["coefficient"]), derived["H2"]["coefficient"]), "H2 coefficient")
    require(close(float(main["se_two_way"]), derived["H2"]["se_two_way"]), "H2 standard error")
    require(
        close(
            100 * math.expm1(float(main["coefficient"])), float(main["percent_log_transform"]), 1e-9
        ),
        "H2 percentage is not exp(coefficient) - 1",
    )
    item_only = one(baselines, cohort="full", group="all", model="item_FE")
    engine = read_json(results / "main_replay/REVIEW_TEST_RESULT.json")["fixed_effect_validation"]
    two_way = next(item for item in engine if item["two_way_fixed_effects"])
    notes = [
        "Model: log(1 + daily units) on a candidate-by-post indicator with item and calendar-day fixed effects; "
        "standard errors clustered by item and by date.",
        f"For comparison, the same sample fitted with item fixed effects and a post-period indicator, "
        f"without calendar-day effects, gives "
        f"{num(item_only['coefficient'])} (item-clustered SE {num(item_only['se_item'])}). "
        f"The item-clustered SE of the two-way model is {num(main['se_item'])}; "
        f"two-way clustering raises it to {num(main['se_two_way'])}.",
        f"The estimator was checked in this run against an explicit dummy-variable regression on a test panel: "
        f"largest difference {two_way['max_coefficient_error']:.1e} in coefficients and "
        f"{two_way['max_two_way_covariance_error']:.1e} in the two-way covariance.",
    ]
    return {
        "head": [
            "Candidate group",
            "Coefficient",
            "SE (two-way)",
            "95% interval",
            "Change",
            "Candidates / controls observed",
            "Item-days",
            "Dates",
        ],
        "rows": table,
        "notes": notes,
        "values": values,
    }


def section_profiles(derived: dict) -> dict:
    def cell(block: dict, what: str) -> str:
        if block["coefficient"] is None:
            return "no exposure inside the window" if what == "floor" else "not estimable"
        if what == "fit":
            return f"{num(block['coefficient'])} ({num(block['se_two_way'])})"
        return f"{pct(block['floors_percent'][0] / 100)} / {pct(block['floors_percent'][1] / 100)}"

    rows = [
        [
            PROFILE_LABELS[item["profile"]],
            cell(item["all"], "fit"),
            cell(item["all"], "floor"),
            cell(item["exclude_cases"], "fit"),
            cell(item["exclude_cases"], "floor"),
        ]
        for item in derived["A3"]
    ]
    require(len(rows) == 8, "eight response profiles expected")
    return {
        "head": [
            "Response profile",
            "All candidates: fitted coefficient (SE)",
            "All candidates: floor, neutral / observed background",
            "Excluding containers: fitted coefficient (SE)",
            "Excluding containers: floor, neutral / observed background",
        ],
        "rows": rows,
    }


def section_floor(results: Path, derived: dict, settings: dict) -> dict:
    scenarios = read_csv(results / "main_replay/results/PRIMARY_SCENARIO_RESULTS.csv")
    calibration = read_csv(results / "main_replay/results/CALIBRATION_TARGETS.csv")
    rows, units, primary = [], [], {}
    for expected in derived["A2"]:
        group, background = expected["group"], expected["background"]
        row = one(
            scenarios,
            cohort="full_archive",
            candidate_group=group,
            model="TWFE",
            background=background,
            scenario="step",
            scale="eventual",
            calibration="frozen150_centered",
        )
        floor = float(row["first_success_fraction"])
        recovered, repetitions = float(row["upper_recovered"]), float(row["upper_repetitions"])
        low, high = wilson(recovered, repetitions)
        require(close(100 * floor, expected["floor_percent"]), f"floor for {group}/{background}")
        require(
            close(100 * recovered / repetitions, expected["recovery_percent"], 1e-6),
            f"recovery for {group}/{background}",
        )
        require(
            close(low, float(row["upper_wilson_low"]))
            and close(high, float(row["upper_wilson_high"])),
            f"Wilson interval for {group}/{background}",
        )
        primary[(group, background)] = floor
        conditional = [
            100 * float(row["conditional_mc_p025"]),
            100 * float(row["conditional_mc_p975"]),
        ]
        require(
            all(
                close(a, float(b))
                for a, b in zip(
                    conditional, expected["retained_conditional_range_percent"], strict=True
                )
            ),
            f"conditional resampling range for {group}/{background}",
        )
        line = [
            GROUP_LABELS[group],
            background.capitalize(),
            pct(floor),
            f"{pct(row['lower_dose_fraction'])} to {pct(floor)}",
            f"{100 * recovered / repetitions:.2f}%",
            f"{100 * low:.2f} to {100 * high:.2f}%",
            f"{100 * float(row['zero_probability']):.2f}%",
            f"{pct(row['conditional_mc_p025'])} to {pct(row['conditional_mc_p975'])}",
        ]
        if SHOW_CALIBRATION_INCLUSIVE_RANGES:
            line += [
                f"{pct(row['iid_date_joint_p025'])} to {pct(row['iid_date_joint_p975'])}",
                f"{pct(row['full_calendar_block_joint_p025'])} to {pct(row['full_calendar_block_joint_p975'])}",
            ]
        rows.append(line)
        units.append(
            [
                GROUP_LABELS[group],
                background.capitalize(),
                pct(floor),
                count(row["pre_volume_denominator"]),
                count(row["mean_added_units_at_floor"]),
            ]
        )
    cal_rows = []
    for group in ("all", "exclude_cases"):
        row = one(calibration, cohort="full_archive", group=group, model="TWFE", scale="eventual")
        cal_rows.append(
            [
                GROUP_LABELS[group],
                count(row["n_dates"]),
                f"{float(row['mean']):.6f}",
                f"{float(row['q95_centered']):.6f}",
            ]
        )
    notes = [
        f"Definition: the detection floor is the first tested dose at which at least {pct(settings['target'])} of "
        f"{count(settings['repetitions'])} repetitions exceed the threshold. The threshold is the 95th percentile of "
        "the mean-centered estimates obtained at the historical calibration dates. There is no interpolation "
        "between doses.",
        "The floor is a tested dose, so the crossing lies between the two adjacent doses shown. "
        "The Wilson interval describes the recovery rate at the floor with the calibration dates held fixed. "
        "The detection rate at zero dose is the share of repetitions "
        "that exceed the threshold when nothing is added.",
        "Range (a) is the 2.5th to 97.5th percentile of the floor over "
        f"{count(settings['bootstrap_repetitions'])} resamples of the simulation paths with calibration held fixed; "
        "it is the range reported in the manuscript.",
    ]
    head = [
        "Candidate group",
        "Background",
        "Floor",
        "Adjacent tested doses",
        "Recovery at the floor",
        "Wilson 95% interval",
        "Detection rate at zero dose",
        "(a) Conditional resampling range",
    ]
    if SHOW_CALIBRATION_INCLUSIVE_RANGES:
        head += [
            "(b) Range, calibration dates also resampled",
            "(c) Range, calendar blocks resampled",
        ]
        notes.append(
            "Ranges (b) and (c) are retained calibration sensitivities in the saved output. Range (b) resamples "
            "the 150 calibration dates as well as the simulation paths. Range (c) uses circular "
            f"{settings['block_days']}-day blocks from the full historical calendar, changing the reference "
            "population as well as resampling it. These ranges are separate from the manuscript's conditional "
            "range (a); none is a confidence interval for an exact population threshold."
        )
    return {
        "head": head,
        "rows": rows,
        "notes": notes,
        "primary": primary,
        "calibration_head": [
            "Candidate group",
            "Calibration dates",
            "Mean of historical estimates",
            "Threshold (mean-centered 95th percentile)",
        ],
        "calibration_rows": cal_rows,
        "units_head": [
            "Candidate group",
            "Background",
            "Floor",
            "Candidate units in the 21 pre-period days",
            "Mean units added over the post-period at the floor",
        ],
        "units_rows": units,
    }


def section_selection(results: Path) -> dict:
    items = read_csv(ROOT / "reviewer_data/ITEM_CLASSIFICATIONS.csv")
    classified = [
        float(row["pre_med_units"])
        for row in items
        if row["whole_word_class"] != "excluded" and row["pre_med_units"] != ""
    ]
    cutoff = quantile_type7(classified, LIQUIDITY_QUANTILE)

    def eligible(row: dict) -> str | None:
        kind, days = row["whole_word_class"], int(row["pre_n_obs"])
        if kind == "key":
            return "key" if days >= 1 else None
        if row["pre_med_price"] == "" or days < MIN_PRE_DAYS:
            return None
        price, units = float(row["pre_med_price"]), float(row["pre_med_units"])
        if kind == "substitute_candidate" and price < CANDIDATE_MAX_PRICE and units > cutoff:
            return "candidate"
        if kind == "control_candidate" and price > CONTROL_MIN_PRICE:
            return "control"
        return None

    chosen = {}
    for row in items:
        arm = eligible(row)
        if arm:
            chosen[row["item"]] = arm
    counts = {
        arm: sum(1 for value in chosen.values() if value == arm)
        for arm in ("candidate", "control", "key")
    }
    require(len({row["item"] for row in items}) == len(items), "duplicate item names in the selection file")
    recorded_items = {
        row["item"]: "candidate" if row["whole_word_arm"] == "substitute" else row["whole_word_arm"]
        for row in items
        if row["whole_word_arm"] != "excluded"
    }
    require(chosen == recorded_items, "re-applied selection differs from the recorded item assignments")
    saved = read_json(results / "main_replay/evidence/SELECTED_COUNTS.json")
    require(
        counts["candidate"] == saved["full|all"]["candidate"]
        and counts["control"] == saved["full|all"]["control"],
        "selection counts differ from the counts used by the saved model fits",
    )
    containers = [
        row["item"]
        for row in read_csv(ROOT / "revision/container_definitions.csv")
        if row["key_dependent_case"] == "True"
    ]
    inside = sum(1 for name in containers if chosen.get(name) == "candidate")
    require(inside == len(containers), "an excluded container is not among the selected candidates")
    remaining = counts["candidate"] - inside
    require(
        remaining == saved["full|exclude_cases"]["candidate"],
        "candidates left after excluding containers",
    )
    return {
        "items": len(items),
        "population": len(classified),
        "cutoff": cutoff,
        "counts": counts,
        "containers": len(containers),
        "remaining": remaining,
    }


def section_dates() -> dict:
    settings = read_json(ROOT / "revision/REVISION_SETTINGS.json")["randomization"]
    rows = read_csv(ROOT / "revision/randomization_dates_frozen.csv")
    listed = [row["date"] for row in rows]
    start, end = date.fromisoformat(settings["start"]), date.fromisoformat(settings["end"])
    calendar = [
        (start + timedelta(days=offset)).isoformat() for offset in range((end - start).days + 1)
    ]
    require(
        len(listed) == settings["n_dates"] == len(set(listed)),
        "calibration dates are not unique or not complete",
    )
    require(set(listed) <= set(calendar), "a calibration date lies outside the stated calendar")
    try:
        import numpy  # available in the pinned environment that runs this report

        draw = numpy.random.default_rng(settings["seed"]).choice(
            len(calendar), settings["n_dates"], replace=False
        )
        require(
            [calendar[index] for index in draw] == listed,
            "the calibration dates do not regenerate exactly from the recorded seed",
        )
    except ImportError as exc:
        raise ValueError("Calibration-date verification requires the pinned numerical library") from exc
    return {
        "n": len(listed),
        "first": min(listed),
        "last": max(listed),
        "calendar_days": len(calendar),
        "seed": settings["seed"],
        "start": settings["start"],
        "end": settings["end"],
        "regenerated": "Yes",
    }


def section_index(results: Path) -> dict:
    rows = [
        row
        for row in read_csv(ROOT / "reviewer_data/H3_INDEX_CONSTRUCTION.csv")
        if (row["scope"], row["keys"], row["recipe"])
        == ("full_zip", "whole_word_27keys", "equal_item_daily_mean_then_equal_days")
    ]
    rows.sort(key=lambda row: int(row["year"]))
    require(len(rows) == 8, "eight annual index rows expected")
    for row in rows:
        require(
            close(float(row["key_price"]) / float(row["candidate_index"]), float(row["ratio"])),
            "index ratio",
        )
    agreement = read_json(results / "main_report/H3_AGREEMENT.json")
    passed = sum(claim["status"] == "PASS" for claim in agreement["claims"])
    require(
        agreement.get("historical_h3") == "MATCH_TO_RETAINED_CALCULATION"
        and len(agreement["claims"]) == passed == 10,
        "the ten H3 comparisons did not all pass",
    )
    return {
        "head": ["Year", "Mean key price (USD)", "Candidate index (USD)", "Key price / index"],
        "rows": [
            [
                row["year"],
                f"{float(row['key_price']):.2f}",
                f"{float(row['candidate_index']):.3f}",
                f"{float(row['ratio']):.2f}",
            ]
            for row in rows
        ],
        "passed": passed,
        "claims": len(agreement["claims"]),
    }


def section_code_identity() -> dict:
    """The readable code must have exactly the same syntax tree as the code that produced the saved results."""
    archive = ROOT / "provenance/as_executed_sources.zip"
    checked = 0
    with zipfile.ZipFile(archive) as originals:
        for name in originals.namelist():
            executed = ast.dump(ast.parse(originals.read(name)))
            readable = ast.dump(ast.parse((ROOT / name).read_bytes()))
            require(
                executed == readable, f"{name} differs in substance from its as-executed original"
            )
            checked += 1
    require(checked > 0, "the as-executed source archive is empty")
    return {"checked": checked}


def section_archive(results: Path, replay: dict) -> dict:
    manifest = read_json(ROOT / "PACKAGE_MANIFEST.json")
    raw = read_json(ROOT / "inputs/public_data_manifest.json")
    pins = {}
    for line in (ROOT / "requirements.txt").read_text(encoding="utf-8-sig").splitlines():
        if "==" in line:
            name, version = line.strip().split("==", 1)
            pins[name] = version
    installed = replay["environment"]["dependencies"]
    require(installed == pins, "installed library versions differ from requirements.txt")
    before = (results / "main_report/package_integrity.log").read_text(encoding="utf-8")
    after = (results / "main_report/package_integrity_after.log").read_text(encoding="utf-8")
    require("mismatches: 0" in before and "mismatches: 0" in after, "package fingerprint check")
    scripts = sum(1 for path in (ROOT / "scripts").rglob("*.py"))
    return {
        "files": len(manifest["files"]),
        "raw_sha256": raw["archive_sha256"],
        "raw_files": len(raw["raw_csv_hashes"]),
        "raw_item_files": sum(
            "/items/" in entry["path"].replace("\\", "/") for entry in raw["raw_csv_hashes"]
        ),
        "python": replay["environment"]["python"],
        "platform": replay["environment"]["platform"],
        "libraries": len(pins),
        "scripts": scripts,
        "core": ", ".join(
            f"{name} {pins[name]}"
            for name in ("numpy", "pandas", "scipy", "statsmodels")
            if name in pins
        ),
    }


def section_quality() -> dict:
    folder = ROOT / "expected_v48/supplementary/provenance"
    raw, final, stamps = (
        read_json(folder / name)
        for name in ("raw_audit.json", "final_data_quality.json", "timestamp_audit.json")
    )
    shifted = sum(
        int(number)
        for offset, number in stamps["unix_minus_text_seconds_counts"].items()
        if offset != "0"
    )
    rows = [
        [
            "Item files in the archive",
            count(raw["raw_item_csvs"]),
            f"{count(final['empty_item_files'])} are empty",
        ],
        ["Records", count(raw["raw_rows"]), f"{count(raw['usable_raw_rows'])} usable"],
        ["Invalid numeric values", count(raw["invalid_numeric_rows"]), ""],
        [
            "Negative or zero quantities; non-positive prices",
            f"{count(raw['negative_units'])}; {count(raw['zero_units_rows'])}; {count(raw['nonpositive_price'])}",
            "",
        ],
        ["Exact duplicate records", count(raw["exact_duplicate_rows"]), ""],
        [
            "Repeated timestamps within an item",
            f"{count(final['timestamp_duplicate_groups'])} groups",
            f"{count(final['same_timestamp_groups_different_prices'])} with different prices, "
            f"{count(final['same_timestamp_groups_different_quantities'])} "
            "with different quantities; all records are kept",
        ],
        [
            "Missing observations",
            f"{count(raw['internal_absent_days'])} absent days inside item histories",
            f"{count(raw['observed_days'])} item-days observed; absent days are left absent, not set to zero",
        ],
        [
            "Sub-daily records",
            f"{count(raw['subdaily_days'])} item-days hold more than one record",
            "quantities are summed within the day; prices are averaged with quantity weights",
        ],
        [
            "Time convention",
            "Unix seconds, UTC, define the calendar day",
            f"written time differs from Unix time in {count(shifted)} records; "
            f"the calendar day differs in {count(raw['date_text_unix_day_mismatch'])}",
        ],
        [
            "Order and validity of timestamps",
            f"{count(raw['nonascending_timestamp_steps'])} out-of-order steps; "
            f"{count(raw['date_text_invalid'])} invalid dates",
            "",
        ],
        [
            "Currency",
            "No currency field in the files",
            "USD is taken from the dataset documentation; no conversion is made",
        ],
    ]
    return {"head": ["Check", "Result", "Detail"], "rows": rows}


# ----------------------------------------------------------------------------- report
def build(results: Path) -> dict:
    settings = read_json(ROOT / "FINAL_SETTINGS.json")
    agreement = read_json(results / "main_report/H2_AGREEMENT.json")
    require(
        agreement["reviewer_requested_h2_agreement"] == "MATCH" and agreement["failure_count"] == 0,
        "the manuscript comparison did not pass",
    )
    derived = agreement["derived"]
    status = section_status(results)
    h2 = section_h2(results, derived)
    profiles = section_profiles(derived)
    floor = section_floor(results, derived, settings)
    selection = section_selection(results)
    dates = section_dates()
    index = section_index(results)
    identity = section_code_identity()
    archive = section_archive(results, status["replay"])
    quality = section_quality()

    turnover = read_json(results / "main_replay/evidence/KEY_TURNOVER.json")[
        "pre21_whole_word_key_units"
    ]
    benchmark = {
        group: 100 * turnover / float(h2["values"][group]["pre_units"])
        for group in ("all", "exclude_cases")
    }
    require(
        close(benchmark["all"], derived["benchmarks_percent"]["all"])
        and close(benchmark["exclude_cases"], derived["benchmarks_percent"]["exclude_containers"]),
        "key-turnover benchmarks",
    )
    main = h2["values"]["all"]

    summary = [
        "R1.1  Floors by response profile, all candidates (neutral / observed): "
        + "; ".join(f"{row[0].lower()} {row[2]}" for row in profiles["rows"] if "/" in row[2]),
        f"R1.2  Two-way fixed effects: coefficient {num(main['coefficient'])} (SE {num(main['se_two_way'])}), "
        f"95% interval {num(main['ci_low_two_way'])} to {num(main['ci_high_two_way'])}, "
        f"{float(main['percent_log_transform']):.2f}%",
        f"R1.3  Abrupt-shift floor: all candidates {pct(floor['primary'][('all', 'neutral')])} neutral, "
        f"{pct(floor['primary'][('all', 'observed')])} observed; excluding containers "
        f"{pct(floor['primary'][('exclude_cases', 'neutral')])} and "
        f"{pct(floor['primary'][('exclude_cases', 'observed')])}",
        f"R1.4  Selection re-applied: {selection['counts']['candidate']:,} candidates, "
        f"{selection['counts']['control']:,} controls, "
        f"{selection['counts']['key']} keys; liquidity cutoff {selection['cutoff']:g}",
        f"R2.2  {archive['files']} package files fingerprint-checked before and after; "
        f"{dates['n']} calibration dates regenerate from the seed: {dates['regenerated']}",
        f"R2.4  Key turnover is {benchmark['all']:.2f}% of all candidate volume and "
        f"{benchmark['exclude_cases']:.2f}% after excluding {selection['containers']} key-dependent containers",
        "R2.5  Saved raw-archive audit: "
        + quality["rows"][1][1]
        + " records, "
        + quality["rows"][2][1]
        + " invalid, "
        + quality["rows"][4][1]
        + " exact duplicates",
    ]
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "settings": settings,
        "status": status,
        "h2": h2,
        "profiles": profiles,
        "floor": floor,
        "selection": selection,
        "dates": dates,
        "index": index,
        "identity": identity,
        "archive": archive,
        "quality": quality,
        "turnover_units": turnover,
        "benchmark": benchmark,
        "summary": summary,
    }


def table(head: list[str], rows: list[list[str]]) -> str:
    out = [
        "<table><thead><tr>"
        + "".join(f"<th>{html.escape(cell)}</th>" for cell in head)
        + "</tr></thead><tbody>"
    ]
    for row in rows:
        out.append("<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>")
    out.append("</tbody></table>")
    return "\n".join(out)


def basis(text: str) -> str:
    return f'<p class="basis">How obtained: {html.escape(text)}</p>'


def paragraphs(items: list[str]) -> str:
    return "\n".join(f"<p>{html.escape(item)}</p>" for item in items)


def render(a: dict) -> str:
    s, sel, dates, arc, st = a["settings"], a["selection"], a["dates"], a["archive"], a["status"]
    main, rest = a["h2"]["values"]["all"], a["h2"]["values"]["exclude_cases"]
    grid = ", ".join(pct(value) for value in s["grid_fraction"])
    hyper = [
        [
            "Candidate rule",
            "name contains Case, Capsule, Graffiti, Sticker, Package or Pin, and is neither a key nor a "
            f"wear-graded item; median price below USD {CANDIDATE_MAX_PRICE:g}; median daily units "
            f"above the cutoff; at least {MIN_PRE_DAYS} observed pre-intervention days",
            "scripts/audit_raw.py",
        ],
        [
            "Control rule",
            "name carries a wear grade (Factory New to Battle-Scarred) and is not a key; "
            f"median price above USD {CONTROL_MIN_PRICE:g}; at least "
            f"{MIN_PRE_DAYS} observed pre-intervention days",
            "scripts/audit_raw.py",
        ],
        [
            "Liquidity cutoff",
            f"{sel['cutoff']:g} units a day: the {100 * LIQUIDITY_QUANTILE:g}th percentile of item "
            f"median daily quantities over {sel['population']:,} classified items with "
            "pre-intervention history",
            "recomputed in this run",
        ],
        [
            "Result of the rules",
            f"{sel['counts']['candidate']:,} candidates, {sel['counts']['control']:,} controls, "
            f"{sel['counts']['key']} keys",
            "recomputed in this run",
        ],
        [
            "Event window",
            f"{s['window'][0]} to {s['window'][1]}; post-period starts {s['post_start']}",
            "FINAL_SETTINGS.json",
        ],
        ["Outcome", s["outcome"], "FINAL_SETTINGS.json"],
        [
            "Calibration dates",
            f"{dates['n']} of the {dates['calendar_days']:,} calendar days from {dates['start']} to "
            f"{dates['end']}, drawn without replacement; seed {dates['seed']}",
            "revision/REVISION_SETTINGS.json",
        ],
        ["Dose grid", f"{len(s['grid_fraction'])} doses: {grid}", "FINAL_SETTINGS.json"],
        [
            "Repetitions per dose",
            f"{s['repetitions']:,}; simulation seed {s['simulation_seed']}",
            "FINAL_SETTINGS.json",
        ],
        [
            "Recovery target",
            f"{pct(s['target'])} of repetitions above the threshold",
            "FINAL_SETTINGS.json",
        ],
        [
            "Precision bought by the repetitions",
            "standard error of a recovery rate at the target: "
            f"{100 * math.sqrt(s['target'] * (1 - s['target']) / s['repetitions']):.2f} percentage points",
            "computed from the two rows above",
        ],
        [
            "Resampling",
            f"{s['bootstrap_repetitions']:,} resamples; seed {s['bootstrap_seed']}; "
            f"calendar blocks of {s['block_days']} days",
            "FINAL_SETTINGS.json",
        ],
    ]
    archive_rows = [
        [
            "Analysis code",
            f"scripts/ ({arc['scripts']} files) and reproduce.py",
            f"{a['identity']['checked']} files were reformatted for "
            "readability; each has the same syntax tree as the "
            "as-executed original kept in provenance/as_executed_sources.zip",
        ],
        [
            "Item classifications",
            f"reviewer_data/ITEM_CLASSIFICATIONS.csv ({sel['items']:,} items)",
            f"re-applying the rules gives {sel['counts']['candidate']:,} "
            f"candidates, {sel['counts']['control']:,} controls "
            f"and {sel['counts']['key']} keys, the counts behind the saved model fits",
        ],
        [
            "Exclusions",
            f"revision/container_definitions.csv ({sel['containers']} key-dependent containers)",
            f"all {sel['containers']} are among the candidates; {sel['remaining']:,} candidates remain",
        ],
        [
            "Randomization dates",
            f"revision/randomization_dates_frozen.csv ({dates['n']} dates, {dates['first']} to {dates['last']})",
            f"regenerated exactly from seed {dates['seed']}: {dates['regenerated']}",
        ],
        [
            "Software versions",
            "requirements.txt",
            f"Python {arc['python']}; {arc['libraries']} libraries installed "
            f"at exactly the pinned versions ({arc['core']})",
        ],
        [
            "File hashes",
            "PACKAGE_MANIFEST.json; inputs/public_data_manifest.json",
            f"{arc['files']} package files matched their fingerprints before "
            "and after the run; the raw archive is pinned by "
            f"SHA-256 {arc['raw_sha256'][:16]}... with fingerprints for {arc['raw_files']:,} raw files, "
            f"of which {arc['raw_item_files']:,} are item histories",
        ],
        [
            "Construction of the collectibles index",
            "reviewer_data/H3_INDEX_CONSTRUCTION.csv; reviewer_data/CLASSIFICATION_AND_INDEX.txt",
            f"annual values below; {a['index']['passed']} of "
            f"{a['index']['claims']} H3 comparisons with the manuscript pass",
        ],
    ]
    injection = [
        [
            "Where the added units go",
            "Each candidate item receives the dose multiplied by its own average daily "
            "units in the 21 pre-period days, on every post-period day on which the item "
            "is observed. Volume is therefore spread across items in proportion to their "
            "pre-period volume; missing item-days stay missing.",
        ],
        [
            "Response profiles",
            "Step: full dose from the first post-period day. Ramp: the dose rises evenly over 7 or "
            "21 days. Delay: no added volume until day 7, 14 or 28. Distributed: each item starts "
            "on its own random day within the post-period. Heterogeneous: each item starts on a "
            "random day from 0 to 7 and approaches the full dose at its own random speed.",
        ],
        [
            "Backgrounds",
            "Neutral: the fitted candidate-by-post change is first removed from the candidate "
            "post-period outcomes. Observed: outcomes are left as recorded, so the added volume must "
            "also overcome the observed decline.",
        ],
        [
            "Noise and decision rule",
            "A mean-centered historical estimate, drawn at random from the calibration dates, "
            "is added to each repetition; the repetition counts as detected when the "
            "resulting coefficient is strictly above the threshold.",
        ],
        [
            "Doses and repetitions",
            f"{len(s['grid_fraction'])} doses, {s['repetitions']:,} repetitions each",
        ],
        [
            "Recorded key turnover",
            f"{count(a['turnover_units'])} key units in the 21 pre-period days",
        ],
        [
            "Benchmark, all candidates",
            f"{a['benchmark']['all']:.2f}% of {count(main['pre_units'])} candidate units",
        ],
        [
            "Benchmark, excluding containers",
            f"{a['benchmark']['exclude_cases']:.2f}% of {count(rest['pre_units'])} candidate units",
        ],
    ]
    style = """
    body{font-family:Segoe UI,Helvetica,Arial,sans-serif;max-width:1080px;margin:28px auto;
         padding:0 22px;color:#1c2733;line-height:1.5}
    h1{font-size:24px;margin-bottom:4px}
    h2{font-size:18px;margin-top:34px;border-top:1px solid #c9d1d9;padding-top:16px}
    h3{font-size:15px;margin-top:20px}
    .sub{color:#56616d;margin-top:0}
    .pass{background:#e6f4ea;border:1px solid #8cc39a;padding:10px 14px;border-radius:6px;
          font-weight:600}
    table{border-collapse:collapse;width:100%;margin:10px 0;font-size:13.5px}
    th,td{border:1px solid #c9d1d9;padding:6px 9px;text-align:left;vertical-align:top}
    th{background:#eef2f6}
    .basis{font-size:12.5px;color:#56616d;margin-top:2px}
    .ask{color:#3b4754;font-style:italic;margin:4px 0 10px}
    """
    parts = [
        "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><title>Reviewer answers: COSE-D-26-04938</title>",
        f"<style>{style}</style></head><body>",
        "<h1>Before the Detector: answers to the reviewers, as produced by this run</h1>",
        f"<p class='sub'>Manuscript COSE-D-26-04938. Run completed {html.escape(a['created_utc'])} (UTC).</p>",
        "<p class='pass'>MAIN REVIEWER CHECKS PASSED</p>",
        table(["Check", "Result"], st["rows"]),
        "<p>This run replays the saved output of the raw-data analysis: it regenerates every summary, repeats the "
        "arithmetic and compares the results with the manuscript. It does not refit the models, because the raw data "
        "(a 900 MB public archive) are not in the package. Under each table "
        "a line states how the numbers were obtained.</p>",
        "<h2>Reviewer 1, comment 1: ramp, delayed, distributed and heterogeneous responses</h2>",
        "<p class='ask'>Requested: simulations and empirical specifications for the four response types.</p>",
        table(a["profiles"]["head"], a["profiles"]["rows"]),
        "<p>Floors are eventual daily amounts added, as a percentage of the candidates' average daily volume in the "
        "21 pre-period days; they are not cumulative added volume. The 28-day delay starts after the 21-day "
        "post-period, so there is no exposure and no coefficient is estimable. The distributed-onset coefficients "
        "equal the 21-day-ramp coefficients because the two average profiles coincide.</p>",
        basis("Coefficients: " + SAVED_FIT + " Floors: " + REPLAY),
        "<h2>Reviewer 1, comment 2: two-way fixed-effects specification</h2>",
        "<p class='ask'>Requested: a specification that absorbs volume changes shared across the market.</p>",
        table(a["h2"]["head"], a["h2"]["rows"]),
        paragraphs(a["h2"]["notes"]),
        basis(SAVED_FIT),
        "<h2>Reviewer 1, comment 3: statistical characterization of the detection floor</h2>",
        "<p class='ask'>Requested: a more complete statistical characterization. "
        "Reviewer 2, comment 4, asks for the Monte Carlo uncertainty and "
        "the result without containers; both are here.</p>",
        table(a["floor"]["head"], a["floor"]["rows"]),
        paragraphs(a["floor"]["notes"]),
        basis(
            "Regenerated from saved model output. Floors, recovery rates and conditional ranges were checked "
            "against the manuscript; the calibration sensitivities were checked against the retained reference tables."
        ),
        "<h3>Calibration behind the threshold</h3>",
        table(a["floor"]["calibration_head"], a["floor"]["calibration_rows"]),
        basis("Recomputed from the retained calibration coefficients and checked against the reference tables."),
        "<h2>Reviewer 1, comment 4: hyperparameter selection</h2>",
        "<p class='ask'>Requested: more details on hyperparameter selection.</p>",
        table(["Setting", "Value", "Where it is recorded"], hyper),
        "<p>The table records the principal selection and simulation settings and their source files. The reasons for the "
        "choices are a matter for the manuscript; this run confirms the values that were actually used.</p>",
        basis(
            "Settings are read from the named files. The cutoff and the item counts are "
            + NOW.lower()
        ),
        "<h2>Reviewer 2, comment 2: reproducibility archive</h2>",
        "<p class='ask'>Requested: analysis code, item classifications, exclusions, randomization dates, file hashes "
        "and the construction of the collectibles index.</p>",
        table(["Requested item", "Where it is", "What this run confirmed"], archive_rows),
        basis(NOW),
        "<h3>Collectibles index and legacy-key price by year</h3>",
        table(a["index"]["head"], a["index"]["rows"]),
        "<p>Recipe: for each day, the index is the mean price across the candidate items observed that day, and "
        "the key price is the mean across the 27 key series observed that day. Each annual value is the mean over "
        "the observed days of the year. Missing item-days are left out, not set to zero.</p>",
        basis(
            SAVED
            + " The ratio column was recomputed; ten manuscript claims were checked against the retained values."
        ),
        "<h2>Reviewer 2, comment 4: implementation of the injection analysis</h2>",
        "<p class='ask'>Requested: how synthetic volume is distributed, the grid, the repetitions, the uncertainty, "
        "the result without containers, and the 30% versus 44% threshold.</p>",
        table(["Item", "Value"], injection),
        table(a["floor"]["units_head"], a["floor"]["units_rows"]),
        f"<p>Under the revised two-way model the two abrupt-shift floors are "
        f"{pct(a['floor']['primary'][('all', 'neutral')])} on a neutral background and "
        f"{pct(a['floor']['primary'][('all', 'observed')])} against the "
        "observed background. They replace the 30% and "
        "44% of the first submission. The uncertainty and the container-excluded results are in the table under "
        "Reviewer 1, comment 3.</p>",
        basis(REPLAY + " The mechanism is implemented in scripts/injection_revision.py."),
        "<h2>Reviewer 2, comment 5: data-quality checks already completed</h2>",
        "<p class='ask'>Requested: completed checks for missing observations, duplicate records, currency and "
        "time-zone conventions, and sub-daily aggregation.</p>",
        table(a["quality"]["head"], a["quality"]["rows"]),
        basis(SAVED),
        "<h2>Not covered by this run</h2>",
        "<p>Reviewer 1, comments 5 and 6 (additional references; a typographical correction), and Reviewer 2, "
        "comments 3 and 6 and the minor presentation suggestions, concern the manuscript text. Reviewer 2, comment 1 "
        "(the dated analysis plans and the mapping table) is answered by the separate plans package.</p>"
        "<p>This run does not recompute the accumulation result (H1), the spike-and-reversal analysis, including the "
        "corpus-wide count of price spikes, the concentration figures, or Figures 2 and 3. These need the raw data "
        "or the separate data and figure packages. The optional raw-data route is described in README.md.</p>",
        "</body></html>",
    ]
    return "\n".join(parts)


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--results", type=Path, required=True, help="Results folder of a completed reviewer run"
    )
    args = parser.parse_args()
    results = args.results.resolve()
    try:
        for filename in ("REVIEWER_ANSWERS.html", "REVIEWER_ANSWERS.json"):
            (results / filename).unlink(missing_ok=True)
        answers = build(results)
        (results / "REVIEWER_ANSWERS.html").write_text(render(answers), encoding="utf-8")
        record = {key: value for key, value in answers.items() if key not in ("status", "settings")}
        record["floor"] = {
            key: value for key, value in answers["floor"].items() if key != "primary"
        }
        record["h2"] = {key: value for key, value in answers["h2"].items() if key != "values"}
        (results / "REVIEWER_ANSWERS.json").write_text(
            json.dumps(record, indent=2) + "\n", encoding="utf-8"
        )
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, SyntaxError) as exc:
        print("ANSWERS REPORT NOT BUILT: " + str(exc), file=sys.stderr)
        return 1
    print("\n".join(answers["summary"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
