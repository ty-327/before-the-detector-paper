#!/usr/bin/env python3
"""Single starting point: run every reviewer check, then show the answers report.

What happens, in order:
  1. The package files are checked against their recorded fingerprints.
  2. A private Python environment with the exact library versions is created
     (first run only; this step needs internet access).
  3. The H2 summary and recovery tables are regenerated from saved model output
     and checked against the reference tables; specified H2/H3 manuscript values
     are compared with the retained evidence.
  4. Control cases confirm that altered results are rejected.
  5. REVIEWER_ANSWERS.html is written, organized by reviewer comment, and opened.

Nothing is written inside the package folder except the private environment
(.reviewer_env). Results go to a new folder under Downloads/COSE_Reviewer_Results.
"""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
EXPECTED = {
    "reviewer_requested_h2_agreement": "MATCH",
    "historical_h3": "MATCH_TO_RETAINED_CALCULATION",
    "negative_tests": "EXPECTED_FAILURES_OBSERVED",
    "portability_integrity_controls": "PASS",
    "replay_regression_controls": "PASS",
}
LABELS = {
    "reviewer_requested_h2_agreement": "Displacement (H2) and detection-floor values agree with the manuscript",
    "historical_h3": "Key-premium (H3) values agree with the manuscript",
    "negative_tests": "Altered results and missing files are rejected",
    "portability_integrity_controls": "Random-number arrays are intact on this computer",
    "replay_regression_controls": "Saved evidence and regenerated results belong together",
}
PASSED = "MAIN REVIEWER CHECKS PASSED"
ATTENTION = "MAIN REVIEWER CHECKS NEED ATTENTION"


def read_result(path):
    result = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(result, dict):
        raise ValueError("The result file must contain a JSON object")
    if result.get("execution_error") or not result.get("completed_utc"):
        raise ValueError(result.get("execution_error") or "The checks did not record completion")
    for field, expected in EXPECTED.items():
        if result.get(field) != expected:
            raise ValueError(f"The required check {field} did not pass")
    replay = result.get("base_replay")
    if not isinstance(replay, dict) or replay.get("status") != "PASS":
        raise ValueError("The main saved-evidence check did not pass")
    return result


def run_logged(command, root, log_path):
    environment = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
    started = time.monotonic()
    with log_path.open("w", encoding="utf-8") as log:
        log.write("Command: " + json.dumps(command) + "\n\n")
        log.flush()
        with subprocess.Popen(
            command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT
        ) as process:
            try:
                while True:
                    try:
                        return process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        seconds = int(time.monotonic() - started)
                        print(
                            f"  Main reviewer checks are running ({seconds} seconds).", flush=True
                        )
            except KeyboardInterrupt:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise


def environment_python(root):
    """Return the interpreter of the private environment that the checks have just used."""
    relative = "Scripts/python.exe" if os.name == "nt" else "bin/python"
    candidate = root / ".reviewer_env" / relative
    return str(candidate) if candidate.is_file() else sys.executable


def build_answers(root, output):
    """Write REVIEWER_ANSWERS.html from the finished run and return its summary lines.

    The interpreter runs in isolated mode (-I), so it loads only the standard library
    and the pinned libraries, and writes no cache files into the package (-B).
    """
    script = root / "reviewer_answers.py"
    if not script.is_file():
        raise FileNotFoundError("reviewer_answers.py is missing. Extract the complete ZIP.")
    command = [environment_python(root), "-I", "-B", "-X", "utf8", str(script),
               "--results", str(output)]
    log_path = output / "2_answers.log"
    with log_path.open("w", encoding="utf-8") as log:
        log.write("Command: " + json.dumps(command) + "\n\n")
        log.flush()
        try:
            done = subprocess.run(
                command, cwd=output, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", timeout=600,
            )
        except subprocess.TimeoutExpired as exc:
            partial = exc.stdout or ""
            if isinstance(partial, bytes):
                partial = partial.decode("utf-8", errors="replace")
            log.write(partial)
            log.write("\nThe answers report exceeded the 600-second time limit.\n")
            raise RuntimeError("The answers report timed out. See 2_answers.log.") from exc
        log.write(done.stdout)
    report = output / "REVIEWER_ANSWERS.html"
    if done.returncode or not report.is_file():
        lines = done.stdout.strip().splitlines()
        detail = lines[-1] if lines else "no report was written"
        raise RuntimeError("The answers report could not be built: " + detail + ". See 2_answers.log.")
    return report, [line for line in done.stdout.splitlines() if line.strip()]


def failure_details(output):
    """Collect the recorded cause and the failing stage's last lines for the reviewer."""
    details = []
    logs = [output / "main_report/package_integrity.log",
            output / "main_report/package_integrity_after.log"]
    for relative, field in (("main_report/REVISION1_STATUS.json", "execution_error"),
                            ("main_replay/REVIEW_TEST_RESULT.json", "error")):
        try:
            receipt = json.loads((output / relative).read_text(encoding="utf-8"))
            if not isinstance(receipt, dict):
                continue
            if receipt.get(field):
                details.append(str(receipt[field]))
            for stage in receipt.get("stages", []):
                if isinstance(stage, dict) and stage.get("status") == "FAIL" and stage.get("log"):
                    path = Path(stage["log"]).resolve()
                    if path.is_relative_to(output):
                        logs.append(path)
        except (OSError, ValueError, TypeError):
            continue
    for path in logs:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        failures = [line for line in lines if line.startswith("FAIL:")]
        if failures:
            details.extend(failures[:3])
        elif path.name not in ("package_integrity.log", "package_integrity_after.log"):
            details.extend(line for line in lines[-3:] if line.strip())
    return " | ".join(dict.fromkeys(details))


def save_report(output, state):
    lines = ["COSE MAIN CODE: REVIEWER CHECK RESULTS", "", state["result"], ""]
    if state.get("error"):
        lines.extend(["Details: " + state["error"], ""])
    if state.get("checks"):
        # Every listed check equals its required value; otherwise the run has already failed.
        lines.extend(LABELS[key] + ": yes" for key in state["checks"])
        lines.append("")
    if state.get("answers"):
        lines.extend(["Answers to the reviewers (full tables: REVIEWER_ANSWERS.html)", ""])
        lines.extend(state["answers"])
        lines.append("")
    lines.extend(
        [
            "What a successful run establishes",
            "The run regenerates the H2 summary and recovery tables from saved model output,",
            "checks their arithmetic and agreement with the bundled reference tables,",
            "compares the specified H2 and H3 values with the bundled manuscript,",
            "and confirms that deliberately altered results are rejected.",
            "",
            "What it does not establish",
            "The models are not refitted: the raw data are not in the package.",
            "Raw-data estimation and Figures 2 and 3 are separate workflows.",
            "The corpus-wide spike count is outside this check.",
            "The analysis plans and the separate data package are checked on their own.",
            "",
            "Main log: " + str(output / "1_main.log"),
            "Detailed reports: " + str(output / "main_report"),
            "Generated results: " + str(output / "main_replay/results"),
            "",
        ]
    )
    if (output / "2_answers.log").is_file():
        lines.extend(["Answers report log: " + str(output / "2_answers.log"), ""])
    report = output / "REVIEWER_CHECK_REPORT.txt"
    report.write_text("\n".join(lines), encoding="utf-8")
    (output / "REVIEWER_CHECK_REPORT.json").write_text(
        json.dumps(state, indent=2) + "\n", encoding="utf-8"
    )
    return report


def run_checks(root, output):
    root, output = root.resolve(), output.resolve()
    if output.exists() or output == root or output.is_relative_to(root):
        raise ValueError("Choose a new results folder outside the main code folder")
    output.mkdir(parents=True)
    state = {
        "result": ATTENTION,
        "checks": {},
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "source_folder": str(root),
        "results_folder": str(output),
        "child_exit_code": None,
        "scope": "Main saved-evidence H2/H3 reviewer checks",
    }
    exit_code = 1
    answers_report = None
    log = output / "1_main.log"
    try:
        script = root / "run_revision1.py"
        if not script.is_file():
            raise FileNotFoundError("run_revision1.py is missing. Extract the complete ZIP.")
        command = [sys.executable, "-I", "-B", "-u", str(script), "--setup"]
        command += ["--work-dir", str(output / "main_replay")]
        command += ["--report-dir", str(output / "main_report")]
        print("Starting the main reviewer checks. Keep this window open.", flush=True)
        print("The first run sets up the required Python packages (internet needed).", flush=True)
        print("A complete run usually takes a few minutes.", flush=True)
        state["child_exit_code"] = run_logged(command, root, log)
        if state["child_exit_code"]:
            detail = "The main check stopped with exit code " + str(state["child_exit_code"])
            cause = failure_details(output)
            if cause:
                detail += ": " + cause
            raise RuntimeError(detail + ". See 1_main.log in the results folder.")
        result = read_result(output / "main_report/REVISION1_STATUS.json")
        state["checks"] = {key: result[key] for key in EXPECTED}
        answers_report, state["answers"] = build_answers(root, output)
        state["answers_report"] = str(answers_report)
        state["result"] = PASSED
        exit_code = 0
    except KeyboardInterrupt:
        state["result"] = "MAIN REVIEWER CHECKS INTERRUPTED"
        state["error"] = "The run was stopped before the checks completed."
        exit_code = 130
    except Exception as exc:
        state["error"] = str(exc)
    state["exit_code"] = exit_code
    state["completed_utc"] = datetime.now(timezone.utc).isoformat()
    report = save_report(output, state)
    print("\n" + state["result"], flush=True)
    if state.get("error"):
        print("Details: " + state["error"], flush=True)
    if state.get("answers"):
        print("\n" + "\n".join(state["answers"]), flush=True)
        print("\nAnswers report: " + str(answers_report), flush=True)
    print("Check report:   " + str(report), flush=True)
    return exit_code, answers_report or report


def open_for_reading(path):
    """Open the report in the default program. Failure to open is not a failed check."""
    try:
        if os.name == "nt":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False, timeout=30)
    except (OSError, subprocess.SubprocessError):
        print("Open the report at the path shown above.", flush=True)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--report-dir", type=Path, help="New results folder outside the main code folder"
    )
    parser.add_argument(
        "--no-open", action="store_true", help="Do not open the report automatically"
    )
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12) or struct.calcsize("P") != 8:
        print("Use 64-bit Python 3.12 for these reviewer checks.", file=sys.stderr)
        return 2
    downloads = Path.home() / "Downloads"
    parent = downloads if downloads.is_dir() else Path.home()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output = args.report_dir or parent / "COSE_Reviewer_Results" / stamp
    try:
        exit_code, report = run_checks(ROOT, output)
    except (OSError, ValueError) as exc:
        print("Unable to start: " + str(exc), file=sys.stderr)
        return 2
    if not args.no_open:
        open_for_reading(report)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
